<form action="quote.php" method="post">
    <h1 class="form-group-heading">
        Stock Quote
    </h1>
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="symbol" placeholder="Quote Lookup" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Submit</button>
        </div>
    </fieldset>
</form>

