<form action="sell.php" method="post">
    <h1 class="form-group-heading">
        Sell Stock
    </h1
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="stock" placeholder="Stock" type="text"/>
        </div>
        <div class="form-group">
            <input autofocus class="form-control" name="units" placeholder="Units" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Sell</button>
        </div>
    </fieldset>
</form>
